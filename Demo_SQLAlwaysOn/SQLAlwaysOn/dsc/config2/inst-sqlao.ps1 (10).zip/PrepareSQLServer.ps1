configuration SQLServerPrepareDsc
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$ssmsName,

        [Parameter(Mandatory)]
        [String]$SApswd,

        [Parameter(Mandatory)]
        [String]$vmNamePrefix,

        [Parameter(Mandatory)]
        [String]$sqlInstanceName,

        [Parameter(Mandatory)]
        [Int]$vmCount,

	    [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLServicecreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AgtServicecreds,

        [Parameter(Mandatory=$true)]
        [String]$ClusterName,

        [Parameter(Mandatory=$true)]
        [String]$AGName,

	[Parameter(Mandatory=$true)]
        [String]$lsn,

        [Parameter(Mandatory=$true)]
        [String]$SysGroupName,

        [Parameter(Mandatory=$true)]
        [String]$ClusterIP,

        [Parameter(Mandatory=$true)]
        [String]$WinClusterIP,

        [Parameter(Mandatory=$true)]
        [String]$witnessStorageBlobEndpoint,

        [Parameter(Mandatory=$true)]
        [String]$witnessStorageAccountKey,

        [Parameter(Mandatory=$true)]
        [String]$isoName,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30,

        [Parameter(Mandatory)]
        [String]$bloburi,
        [Parameter(Mandatory)]
        [String]$blobSAS,
        [parameter(Mandatory=$true)]
        [string]$Edition,
        [bool] $AttachDisk = $false,
        [bool] $WriteVault = $false,
        [string] $RoleID = "this_is_a_role_id",
        [string] $SecretID = "this_is_a_secret_id"
    )
    
    Import-DscResource -ModuleName xComputerManagement -ModuleVersion 3.2.0.0
    Import-DscResource -ModuleName xNetworking -ModuleVersion 5.4.0.0
    Import-DscResource -ModuleName xActiveDirectory -ModuleVersion 2.16.0.0
    Import-DscResource -ModuleName xStorage -ModuleVersion 3.4.0.0
    Import-DscResource -ModuleName xFailoverCluster -ModuleVersion 1.8.0.0
    #Import-DscResource -ModuleName SqlServer -ModuleVersion 21.0.17199
    Import-DscResource -ModuleName SqlServerDsc -ModuleVersion 10.0.0.0
    Import-DscResource -ModuleName StorageDSC -ModuleVersion 4.8.0.0
    Import-DscResource -ModuleName SmbShare
    Import-DscResource -ModuleName xSMBShare -ModuleVersion 2.0.0.0
    Import-DscResource -ModuleName cNtfsAccessControl -ModuleVersion 1.4.1
    Import-DscResource -ModuleName xPSDesiredStateConfiguration

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$SQLCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($SQLServicecreds.UserName)", $SQLServicecreds.Password)
    [System.Management.Automation.PSCredential]$AgtCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($AgtServicecreds.UserName)", $AgtServicecreds.Password)

    $SQLUserName=$SQLCreds.UserName
    $SQLPassword=$SQLCreds.GetNetworkCredential().password
    $AgtUserName=$AgtCreds.UserName
    $AgtPassword=$AgtCreds.GetNetworkCredential().password
    $Sysadmingroupname="$DomainNetbiosName\$SysGroupName"

    #$ipcomponents = $ClusterIP.Split('.')
    #$ipcomponents[3] = [convert]::ToString(([convert]::ToInt32($ipcomponents[3])) + 1)
    $ipdummy = $WinClusterIP
    $ClusterNameDummy = "hsp" + $ClusterName

    $suri = [System.uri]$witnessStorageBlobEndpoint
    $uricomp = $suri.Host.split('.')

    $witnessStorageAccount = $uriComp[0]
    $witnessEndpoint = $uricomp[-3] + "." + $uricomp[-2] + "." + $uricomp[-1]

    $computerName = $env:COMPUTERNAME
    $domainUserName = $DomainCreds.UserName.ToString()

    [System.Collections.ArrayList]$Nodes=@()
    For ($count=0; $count -lt $vmCount; $count++) {
        $Nodes.Add($vmNamePrefix + $Count.ToString())
    }

    
    $ClusterOwnerNode = $Nodes[0]

    Node localhost
    {
		$Disk2PartitionStyle = Get-Disk | ?{ $_.Number -eq 2 } | %{ $_.PartitionStyle }
        if($AttachDisk -and ($Disk2PartitionStyle -eq 'raw'))
        {
          xWaitforDisk Disk2
          {
            DiskId = 2
            RetryIntervalSec = 20
            RetryCount = 30
          }

          xDisk ADDataDisk {
            DiskId = 2
            DriveLetter = "F"
            DependsOn = "[xWaitForDisk]Disk2"
          }
        }

	xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
        }

        if($WriteVault)
        {
          File C_Chef
          {
            Type = "Directory"
            Ensure = "Present"
            DestinationPath = "c:\chef"
          }

          File C_Chef_Hash
          {
            Type = "Directory"
            Ensure = "Present"
            DestinationPath = "c:\chef\hash"
          }

          File SQLConfig {
            Type = "Directory"
            Ensure = "Present"
            DestinationPath = "c:\sqlconfig"
          }
      
      $app_json_contents = "{ ```"role_id```":```"$RoleID```", ```"secret_id```":```"$SecretID```" }"
      $SetScript = @"
        `$app_json = "$app_json_contents"
        `$Utf8NoBomEncoding = New-Object System.Text.UTF8Encoding `$False
        [System.IO.File]::WriteAllLines("c:\chef\hash\app.json", `$app_json, `$Utf8NoBomEncoding)
"@
      $TestScript = @"
        `$app_json = "$app_json_contents"
        if(-not (Test-Path "c:\chef\hash\app.json"))
        {
          return `$false
        }
        return ((Get-content "c:\chef\hash\app.json") -join '') -eq "$app_json_contents"
"@
          Script BatFile
          {
            SetScript = [Scriptblock]::Create($SetScript)
            TestScript = [Scriptblock]::Create($TestScript)
            GetScript = { @{BatFileExists = (Test-Path "c:\chef\hash\app.json" )} }
          }
        }

        $date = (Get-Date)
        File timestamp
        {
          Ensure = "Present"
          DestinationPath = "c:\dsclog.txt"
          Contents = "Last DSC converge: $date"
        }

        $FileName = 'microsoft-windows-netfx3-ondemand-package.cab'
        xRemoteFile Download-NetFile {  
            Uri             = "$bloburi/$FileName$blobSAS"
            DestinationPath = "C:\SQLConfig\$FileName"
            MatchSource     = $false
        }
        
        WindowsFeature 'NetFramework35'
        {
            Name   = 'NET-Framework-Core'
            Ensure = 'Present'
            Source = 'C:\SQLConfig'
        }

        WindowsFeature 'NetFramework45'
        {
            Name   = 'NET-Framework-45-Core'
            Ensure = 'Present'
        }

        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

        WindowsFeature FailoverClusterTools 
        { 
            Ensure = "Present" 
            Name = "RSAT-Clustering-Mgmt"
            DependsOn = "[WindowsFeature]FC"
        } 

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]FailoverClusterTools"
        }
     
        WindowsFeature FCPSCMD
        {
            Ensure    = 'Present'
            Name      = 'RSAT-Clustering-CmdInterface'
            DependsOn = '[WindowsFeature]FCPS'
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        
        <#TODO: Add user for running SQL server.
        xADUser SvcUser
        {

        }
        #>

        xRemoteFile Download-SQL {  
            Uri             = "$bloburi/$isoName$blobSAS"
            DestinationPath = "C:\SQLConfig\$isoName"
            MatchSource     = $false
        }

        xRemoteFile Download-SSMs {  
            Uri             = "https://aka.ms/ssmsfullsetup"
            DestinationPath = "C:\SQLConfig\$ssmsName"
            MatchSource     = $false
        }

	    if($Edition -eq 'Enterprise (x64)') {
           $msiFileName = $isoName
        }
        else {
           $msiFIleName = $isoName
        }
        MountImage ISO
        {
            ImagePath   = "c:\SQLConfig\$msiFileName"
            DriveLetter = 'S'
        }

        start-sleep -seconds 60
        WaitForVolume WaitForISO
        {
            DriveLetter      = 'S'
            RetryIntervalSec = 5
            RetryCount       = 10
        }

        Script 'InstallNamedInstance-INST2016'{
            GetScript = { 
                $sqlInstance=$using:sqlInstanceName
                $sqlpath = "HKLM:\Software\Microsoft\Microsoft SQL Server\$sqlInstance"
                Test-Path $sqlpath
                @{Ensure = if (Test-Path $sqlpath) {'Present'} else {'Absent'}}
            }

            SetScript = {
                Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False
                $SQLUserName=$using:SQLUserName
                $SQLPassword=$using:SQLPassword

                $AgtUserName=$using:AgtUserName
                $AgtPassword=$using:AgtPassword
                $sqlInstanceName=$using:sqlInstanceName
                $Sysadmingroupname=$using:Sysadmingroupname
                $SApswd=$using:SApswd

                #S:\setup /ACTION=Install /SQLBACKUPDIR='H:\Backups' /AGTSVCACCOUNT=$AgtUserName /SQLUSERDBDIR='H:\SQLDATA' /SQLSVCPASSWORD=$SQLPassword /AGTSVCSTARTUPTYPE='Automatic' /IACCEPTSQLSERVERLICENSETERMS='True' /SQLTEMPDBLOGDIR='L:\SQLLOG' /INSTALLSHAREDWOWDIR='F:\Program Files (x86)\Microsoft SQL Server' /AGTSVCPASSWORD=$AgtPassword /QUIET='True' /INSTANCENAME=$sqlInstanceName /INSTANCEDIR='F:\Program Files\Microsoft SQL Server' /SQLUSERDBLOGDIR='L:\SQLLOG' /SQLSYSADMINACCOUNTS=$SQLUsername $Sysadmingroupname /SQLTEMPDBDIR='T:\SQLTMP' /SQLCOLLATION='SQL_Latin1_General_CP1_CI_AS' /SQLSVCACCOUNT=$SQLUsername /FEATURES=SQLENGINE,REPLICATION,FULLTEXT,CONN,BC,SDK /INSTALLSQLDATADIR='H:\' /INSTALLSHAREDDIR='C:\Program Files\Microsoft SQL Server' /UPDATEENABLED='False' /BROWSERSVCSTARTUPTYPE='Automatic' /SQLSVCINSTANTFILEINIT='True' /SECURITYMODE='SQL' /SAPWD=$SApswd
		S:\setup /ACTION=Install /SQLBACKUPDIR='C:\Backups' /AGTSVCACCOUNT=$AgtUserName /SQLUSERDBDIR='C:\SQLDATA' /SQLSVCPASSWORD=$SQLPassword /AGTSVCSTARTUPTYPE='Automatic' /IACCEPTSQLSERVERLICENSETERMS='True' /SQLTEMPDBLOGDIR='C:\SQLLOG' /INSTALLSHAREDWOWDIR='C:\Program Files (x86)\Microsoft SQL Server' /AGTSVCPASSWORD=$AgtPassword /QUIET='True' /INSTANCENAME=$sqlInstanceName /INSTANCEDIR='C:\Program Files\Microsoft SQL Server' /SQLUSERDBLOGDIR='C:\SQLLOG' /SQLSYSADMINACCOUNTS=$SQLUsername $Sysadmingroupname /SQLTEMPDBDIR='C:\SQLTMP' /SQLCOLLATION='SQL_Latin1_General_CP1_CI_AS' /SQLSVCACCOUNT=$SQLUsername /FEATURES=SQLENGINE,REPLICATION,FULLTEXT,CONN,BC,SDK /INSTALLSQLDATADIR='C:\' /INSTALLSHAREDDIR='C:\Program Files\Microsoft SQL Server' /UPDATEENABLED='False' /BROWSERSVCSTARTUPTYPE='Automatic' /SQLSVCINSTANTFILEINIT='True' /SECURITYMODE='SQL' /SAPWD=$SApswd
                
            }

            TestScript = {
                $sqlInstance=$using:sqlInstanceName
                $sqlpath = "HKLM:\Software\Microsoft\Microsoft SQL Server\$sqlInstance"
                Test-Path $sqlpath
            }


            
            PsDscRunAsCredential = $DomainCreds
        }

       
        # Script ResetSpns
        # {
        #     GetScript = { 
        #         return @{ 'Result' = $true }
        #     }

        #     SetScript = {
        #         $spn = "MSSQLSvc/" + $using:computerName + "." + $using:DomainName
                
        #         $cmd = "setspn -D $spn $using:computerName"
        #         Write-Verbose $cmd
        #         Invoke-Expression $cmd

        #         $cmd = "setspn -A $spn $using:SqlUsername"
        #         Write-Verbose $cmd
        #         Invoke-Expression $cmd

        #         $spn = "MSSQLSvc/" + $using:computerName + "." + $using:DomainName + ":1433"
                
        #         $cmd = "setspn -D $spn $using:computerName"
        #         Write-Verbose $cmd
        #         Invoke-Expression $cmd

        #         $cmd = "setspn -A $spn $using:SqlUsername"
        #         Write-Verbose $cmd
        #         Invoke-Expression $cmd
        #     }

        #     TestScript = {
        #         $false
        #     }

            
        #     PsDscRunAsCredential = $DomainCreds
        # }
       

        if ($ClusterOwnerNode -eq $env:COMPUTERNAME) { 
               
            
            Script Create_Database {
                GetScript = { 
                    $instanceName = $using:sqlInstanceName
                    $serverName = $env:COMPUTERNAME

                    if($instanceName -eq 'MSSQLServer') {
                        $serverInstance = "$serverName"
                    }
                    else {
                        $serverInstance = "$serverName\$instanceName"
                    }
                
                    $count = (Get-SqlDatabase -ServerInstance $serverInstance | where{$_.name -eq 'testdb'}).count

                    if($count -eq 0) {
                        $False
                    }
                    else {
                        $True
                    }
                }
                SetScript = {
                    import-module sqlserver

                    $instanceName = $using:sqlInstanceName
                    $serverName = $env:COMPUTERNAME

                    if($instanceName -eq 'MSSQLServer') {
                        $sqlPath = "default"
                    }
                    else {
                        $sqlPath = "$instanceName"
                    }

                    cd sqlserver: 
                    cd \sql\localhost\  
                    $srv = get-item $sqlPath  
  
                    #Create a new database  
                    $db = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Database -argumentlist $srv, "testdb"  
                    $db.Create()
                }
                TestScript = {
                    $instanceName = $using:sqlInstanceName
                    $serverName = $env:COMPUTERNAME

                    if($instanceName -eq 'MSSQLServer') {
                        $serverInstance = "$serverName"
                    }
                    else {
                        $serverInstance = "$serverName\$instanceName"
                    }
                
                    $count = (Get-SqlDatabase -ServerInstance $serverInstance | where{$_.name -eq 'testdb'}).count

                    if($count -eq 0) {
                        $False
                    }
                    else {
                        $True
                    }
                }
                PsDscRunAsCredential = $SQLCreds  
            }       

            Script CreateCluster {
                SetScript = {
                    $ClusterNameDummy = $using:ClusterNameDummy
                    $ipdummy = $using:ipdummy

                    New-Cluster -Name $ClusterNameDummy -StaticAddress $ipdummy -ErrorAction SilentlyContinue
                    
                }
                TestScript = {
                    $ClusterNameDummy = $using:ClusterNameDummy
                    
                    try {
                        (Get-Cluster -Name $ClusterNameDummy -ErrorAction SilentlyContinue).Name -eq $ClusterNameDummy
                    }
                    catch {
                        $ErrorMessage = $_.Exception.Message
                        Write-Information $ErrorMessage
                    }
                }
                GetScript = {
                    $ClusterNameDummy = $using:ClusterNameDummy
                    @{Ensure = if ((Get-Cluster -Name $ClusterNameDummy -ErrorAction SilentlyContinue).Name -eq $ClusterNameDummy) {'Present'} else {'Absent'}}
                }
                DependsOn = "[WindowsFeature]FCPSCMD"
                PsDscRunAsCredential = $DomainCreds
            }

            Script CloudWitness
            {
                SetScript = {
                    Set-ClusterQuorum -CloudWitness -AccountName $using:witnessStorageAccount -AccessKey $using:witnessStorageAccountKey
                }
                TestScript = {
                    (Get-ClusterQuorum).QuorumResource.Name -eq 'Cloud Witness'
                }
                GetScript = {
                    @{Ensure = if ((Get-ClusterQuorum).QuorumResource.Name -eq 'Cloud Witness') {'Present'} else {'Absent'}}
                }
                DependsOn = "[Script]CreateCluster"
            }

            Script EnableAlwaysOn {
                GetScript = { 
                    return $true 
                }
                SetScript = {
                    $instanceName = $using:sqlInstanceName
                    $serverName = $env:COMPUTERNAME

                    if($instanceName -eq 'MSSQLServer') {
                        $serverInstance = "$serverName"
                    }
                    else {
                        $serverInstance = "$serverName\$instanceName"
                    }

                    Enable-SqlAlwaysOn �ServerInstance "$serverInstance" -Force

                }
                TestScript = {
                    return $false 
                }
                DependsOn = "[Script]CreateCluster"
            
            }


            # Create a DatabaseMirroring endpoint
            SqlServerEndpoint HADREndpoint
            {
                EndPointName         = 'HADR'
                Ensure               = 'Present'
                Port                 = 5022
                ServerName           = $env:COMPUTERNAME
                InstanceName         = $sqlInstanceName
                DependsOn            = "[Script]EnableAlwaysOn"
            }

            # Create the availability group on the instance tagged as the primary replica
            SqlAG CreateAG
            {
                Ensure               = "Present"
                Name                 = $AGName
                ServerName           = $env:COMPUTERNAME
                InstanceName         = $sqlInstanceName
                #DependsOn            = "[Script]CreateCluster,[SqlServerEndpoint]HADREndpoint"
                AvailabilityMode     = "SynchronousCommit"
                FailoverMode         = "Automatic" 
                DependsOn            = "[SqlServerEndpoint]HADREndpoint"
            }

            SqlAGListener AvailabilityGroupListener
            {
                Ensure               = 'Present'
                ServerName           = $ClusterOwnerNode
                InstanceName         = $sqlInstanceName
                AvailabilityGroup    = $AGName
                Name                 = $lsn
                IpAddress            = "$ClusterIP/255.255.255.224"
                Port                 = 1433
                PsDscRunAsCredential = $SQLCreds
                DependsOn            = "[SqlAG]CreateAG"
            }

            SqlWaitForAG WaitForAG
              {
                  Name                 = $AGName
                  RetryIntervalSec     = 20
                  RetryCount           = 30
                  PsDscRunAsCredential = $SQLCreds
                  DependsOn                  = "[SqlAG]CreateAG"
              }
#F
            File BackupDirectory
            {
                Ensure = "Present" 
                Type = "Directory" 
                DestinationPath = "C:\Backup"    
            }

#F
            xSMBShare DBBackupShare
            {
                Name = "DBBackup"
                Path = "C:\Backup"
                Ensure = "Present"
                FullAccess = $SQLCreds.UserName
                Description = "Backup share for SQL Server"
                DependsOn = "[File]BackupDirectory"
            }

#F
		cNtfsPermissionEntry NTFPermissions
            {
                Ensure = 'Present'
                Path = "C:\Backup"
                Principal = $SQLCreds.UserName
                AccessControlInformation = @(
                    cNtfsAccessControlInformation
                    {
                        AccessControlType = 'Allow'
                        FileSystemRights = 'FullControl'
                        Inheritance = 'ThisFolderSubfoldersAndFiles'
                        NoPropagateInherit = $false
                    }
                )
                DependsOn = '[File]BackupDirectory'
            }

            SqlAGDatabase AddDatabaseToAG
            {
                AvailabilityGroupName   = $AGName
                BackupPath              = "\\" + $env:COMPUTERNAME + "\DBBackup"
                DatabaseName            = 'TestDB'
                InstanceName            = $sqlInstanceName
                ServerName              = $env:COMPUTERNAME
                Ensure                  = 'Present'
                ProcessOnlyOnActiveNode = $true
                PsDscRunAsCredential    = $SQLCreds
                DependsOn               = "[SqlAG]CreateAG"
            }
            
            

            Script SetProbePort
            {

                GetScript = { 
                    return @{ 'Result' = $true }
                }
                SetScript = {
                    $ipResourceName = $using:AGName + "_" + $using:ClusterIP
                    $ipResource = Get-ClusterResource $ipResourceName
                    $clusterResource = Get-ClusterResource -Name $using:AGName 

                    Set-ClusterParameter -InputObject $ipResource -Name ProbePort -Value 59999

                    Stop-ClusterResource $ipResource
                    Stop-ClusterResource $clusterResource

                    Start-ClusterResource $clusterResource #This should be enough
                    Start-ClusterResource $ipResource #To be on the safe side

                }
                TestScript = {
                    $ipResourceName = $using:AGName + "_" + $using:ClusterIP
                    $resource = Get-ClusterResource $ipResourceName
                    $probePort = $(Get-ClusterParameter -InputObject $resource -Name ProbePort).Value
                    Write-Verbose "ProbePort = $probePort"
                    ($(Get-ClusterParameter -InputObject $resource -Name ProbePort).Value -eq 59999)
                }
                DependsOn = "[SqlAGListener]AvailabilityGroupListener"
                PsDscRunAsCredential = $DomainCreds
            }

        } else {
            xWaitForCluster WaitForCluster
            {
                Name             = $ClusterNameDummy
                RetryIntervalSec = 10
                RetryCount       = 60
                DependsOn        = "[WindowsFeature]FCPSCMD"
            }

            #We have to do this manually due to a problem with xCluster:
            #  see: https://github.com/PowerShell/xFailOverCluster/issues/7
            #      - Cluster is added with an IP and the xCluster module tries to access this IP. 
            #      - Cluster is not not yet responding on that addreess
            Script JoinExistingCluster
            {
                GetScript = { 
                    $targetNodeName = $env:COMPUTERNAME
                    $ClusterOwnerNode = $using:ClusterOwnerNode
                    
                    @{Ensure = if ((Get-ClusterNode -Cluster $ClusterOwnerNode -ErrorAction SilentlyContinue).name -contains $targetNodeName) {'Present'} else {'Absent'}}

                }

                SetScript = {
                    $targetNodeName = $env:COMPUTERNAME
                    $ClusterOwnerNode = $using:ClusterOwnerNode
                    Add-ClusterNode -Name $targetNodeName -Cluster $ClusterOwnerNode
                }
                TestScript = {
                    $targetNodeName = $env:COMPUTERNAME
                    $ClusterOwnerNode = $using:ClusterOwnerNode
                    
                    try {
                        (Get-ClusterNode -Cluster $ClusterOwnerNode -ErrorAction SilentlyContinue).name -contains $targetNodeName
                    }
                    catch {
                        $ErrorMessage = $_.Exception.Message
                        Write-Information $ErrorMessage
                    }
                }

                DependsOn = "[xWaitForCluster]WaitForCluster"
                PsDscRunAsCredential = $DomainCreds
            }

            
            Script EnableAlwaysOn {
                GetScript = { 
                    return $true 
                }
                SetScript = {
                    $instanceName = $using:sqlInstanceName
                    $serverName = $env:COMPUTERNAME

                    if($instanceName -eq 'MSSQLServer') {
                        $serverInstance = "$serverName"
                    }
                    else {
                        $serverInstance = "$serverName\$instanceName"
                    }

                    Enable-SqlAlwaysOn �ServerInstance "$serverInstance" -Force

                }
                TestScript = {
                    return $false 
                }
            
            }

              # Create a DatabaseMirroring endpoint
              SqlServerEndpoint HADREndpoint
              {
                  EndPointName         = 'HADR'
                  Ensure               = 'Present'
                  Port                 = 5022
                  ServerName           = $env:COMPUTERNAME
                  InstanceName         = $sqlInstanceName
                  DependsOn            = "[Script]EnableAlwaysOn"
              }

            <#
            Script RestoreDatabase
            {
                GetScript = { 
                    return @{ 'Result' = $true }
                }
                SetScript = {
                    $instanceName = $using:sqlInstanceName
                    $serverName = $env:COMPUTERNAME
                    $backupFile = "\\" + $using:ClusterOwnerNode + "\DBBackup\testdb.bak"

                    if($instanceName -eq 'MSSQLServer') {
                        $serverInstance = $serverName
                    }
                    else {
                        $serverInstance = "$serverName\$instanceName"
                    }

                    Restore-SqlDatabase -ServerInstance $serverInstance -Database "TestDB" -BackupFile $backupFile

                }
                TestScript = {
                    return @{ 'Result' = $false }
                }
                DependsOn = "[SqlAGListener]AvailabilityGroupListener"
                PsDscRunAsCredential = $SQLCreds
              }
              #>

              SqlWaitForAG WaitForAG
              {
                  Name                 = $AGName
                  RetryIntervalSec     = 20
                  RetryCount           = 30
                  PsDscRunAsCredential = $SQLCreds
                  DependsOn                  = "[SqlServerEndpoint]HADREndpoint"
              }
      
                # Add the availability group replica to the availability group
                
                $computerName = $env:COMPUTERNAME
                if($sqlInstanceName -eq 'MSSQLSERVER') {
                    $connectionString = "$computerName"
                }
                else {
                    $connectionString = "$computerName\$sqlInstanceName"
                }
                SqlAGReplica AddReplica
                {
                    Ensure                     = 'Present'
                    Name                       = $connectionString
                    AvailabilityGroupName      = $AGName
                    ServerName                 = $env:COMPUTERNAME
                    InstanceName               = $sqlInstanceName
                    PrimaryReplicaServerName   = $ClusterOwnerNode
                    PrimaryReplicaInstanceName = $sqlInstanceName
                    PsDscRunAsCredential = $SQLCreds
                    AvailabilityMode     = "SynchronousCommit"
                    FailoverMode         = "Automatic"
                    DependsOn            = "[SqlWaitForAG]WaitForAG"     
                } 

                SqlAGListener AvailabilityGroupListener
                {
                    Ensure               = 'Present'
                    ServerName           = $env:COMPUTERNAME
                    InstanceName         = $sqlInstanceName
                    AvailabilityGroup    = $AGName
                    Name                 = $lsn
                    IpAddress            = "$ClusterIP/255.255.255.224"
                    Port                 = 1433
                    PsDscRunAsCredential = $SQLCreds
                    DependsOn            = "[SqlAGReplica]AddReplica"
                }
            #     Script RestoreDatabase
            # {

            #     GetScript = { 
            #         return @{ 'Result' = $true }
            #     }
            #     SetScript = {
            #         $instanceName = $using:sqlInstanceName
            #         $serverName = $env:COMPUTERNAME
            #         $pserver=$using:clusterownernode
            #         $backupFile = "\\" + $using:ClusterOwnerNode + "\DBBackup\testdb.bak"
            #         $LogBackupFile="\\" + $using:ClusterOwnerNode + "\DBBackup\testdb.trn"
            #         $agName=$using:ClusterName
                    
            #         if($instanceName -eq 'MSSQLServer') {
            #             $serverInstance = $serverName
            #             $primaryInstance = $pserver
            #         }
            #         else {
            #             $serverInstance = "$serverName\$instanceName"
            #             $primaryInstance = "$pserver\$instanceName"
            #         }
		            
                    
                    
            #         Backup-SqlDatabase -Database "testdb" -BackupFile $BackupFile -ServerInstance $primaryInstance
            #         Backup-SqlDatabase -Database "testdb" -BackupFile $LogBackupFile -ServerInstance $primaryInstance -BackupAction Log
            #         Restore-SqlDatabase -ServerInstance $serverInstance -Database "TestDB" -BackupFile $backupFile -RestoreAction Database -NoRecovery
            #         Restore-SqlDatabase -Database "TestDB" -BackupFile $LogBackupFile -ServerInstance $serverInstance -RestoreAction Log -NoRecovery
		    # Start-Sleep -Seconds 30
            #         Add-SqlAvailabilityDatabase -Path "SQLSERVER:\SQL\$serverInstance\AvailabilityGroups\$agName" -Database "testdb"

            #     }
            #     TestScript = {
            #         $instanceName = $using:sqlInstanceName
            #         $serverName = $env:COMPUTERNAME

            #         if($instanceName -eq 'MSSQLServer') {
            #             $serverInstance = "$serverName\DEFAULT"
            #         }
            #         else {
            #             $serverInstance = "$serverName\$instanceName"
            #         }
                    
            #         $count = (Get-SqlDatabase -ServerInstance $serverInstance | where{$_.name -eq 'testdb'}).count

            #         if($count -eq 0) {
            #             $False
            #         }
            #         else {
            #             $True
            #         }
            #     }
            #     PsDscRunAsCredential = $SQLCreds
            #   }
            Script RestoreDatabase {

                GetScript = { 
                    return @{ 'Result' = $true }
                }
                SetScript = {
		    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                    remove-module sqlserver -force
                    install-module sqlserver -allowclobber -force
                    import-module sqlserver
                    $instanceName = $using:sqlInstanceName
                    $serverName = $env:COMPUTERNAME
                    $pserver=$using:clusterownernode
                    $backupFile = "\\" + $using:ClusterOwnerNode + "\DBBackup\testdb.bak"
                    $LogBackupFile="\\" + $using:ClusterOwnerNode + "\dbbackup\testdb.trn"
                    $agName=$using:AGName
                
                    if($instanceName -eq 'MSSQLSERVER') {
                        $serverInstance = $serverName
                        $primaryInstance = $pserver
                        $serverPath = "$serverName\DEFAULT"
                    }
                    else {
                        $serverInstance = "$serverName\$instanceName"
                        $primaryInstance = "$pserver\$instanceName"
                        $serverPath = "$serverName\$instanceName"
                    }
                     
                
                
                    Backup-SqlDatabase -Database "testdb" -BackupFile $BackupFile -ServerInstance $primaryInstance
                    Backup-SqlDatabase -Database "testdb" -BackupFile $LogBackupFile -ServerInstance $primaryInstance -BackupAction Log
                    Restore-SqlDatabase -ServerInstance $serverInstance -Database "TestDB" -BackupFile $backupFile -RestoreAction Database -NoRecovery
                    Restore-SqlDatabase -Database "TestDB" -BackupFile $LogBackupFile -ServerInstance $serverInstance -RestoreAction Log -NoRecovery
                    $sqlpath = "SQLSERVER:\SQL\$serverPath\AvailabilityGroups\$agName"
                    set-location $sqlpath
                    Add-SqlAvailabilityDatabase -Path $sqlpath -Database "testdb"

                }
                TestScript = {
                    $instanceName = $using:sqlInstanceName
                    $serverName = $env:COMPUTERNAME

                    if($instanceName -eq 'MSSQLServer') {
                        $serverInstance = "$serverName"
                    }
                    else {
                        $serverInstance = "$serverName\$instanceName"
                    }
                
                    $count = (Get-SqlDatabase -ServerInstance $serverInstance | where{$_.name -eq 'testdb'}).count

                    if($count -eq 0) {
                        $False
                    }
                    else {
                        $True
                    }
                }
                PsDscRunAsCredential = $SQLCreds
              }

           
        }


        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }
    }
}

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}